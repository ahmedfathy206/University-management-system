package university;

import java.sql.*;

public class StudentManager extends UserManager {

    public StudentManager(Connection conn) {
        super(conn);
    }

   public void addStudent(int userId, int departmentId) throws SQLException {
    String sql = "INSERT INTO students (user_id, department_id) VALUES (?, ?)";
    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setInt(1, userId);
        pstmt.setInt(2, departmentId);
        pstmt.executeUpdate();
        System.out.println("Student added.");
    }
}

    public void deleteStudent(int studentId) throws SQLException {
        String sql = "DELETE FROM students WHERE student_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, studentId);
            pstmt.executeUpdate();
            System.out.println("Student deleted.");
        }
    }
    public void viewAllStudents(Connection conn) throws SQLException {
        String sql = "SELECT s.student_id, u.username, u.email, d.name AS department_name " +
                     "FROM students s " +
                     "JOIN users u ON s.user_id = u.user_id " +
                     "JOIN departments d ON s.department_id = d.department_id";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("student_id") +
                                   ", Username: " + rs.getString("username") +
                                   ", Email: " + rs.getString("email") +
                                   ", Department: " + rs.getString("department_name"));
            }
        }
    }
}
