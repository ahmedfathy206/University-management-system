package university;

import java.sql.*;

public class StaffManager extends UserManager {

    public StaffManager(Connection conn) {
        super(conn);
    }

    // Add a staff member (must first be a user)
    public void addAcademicStaff(int userId, int departmentId) throws SQLException {
    String sql = "INSERT INTO academic_staff (user_id, department_id) VALUES (?, ?)";
    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setInt(1, userId);
        pstmt.setInt(2, departmentId);
        pstmt.executeUpdate();
        System.out.println("Academic staff added.");
    }
}

    // Assign a course to a staff member
    public void assignCourse(int staffId, int courseId) throws SQLException {
        String sql = "INSERT INTO courses_staff (staff_id, course_id) VALUES (?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, staffId);
            pstmt.setInt(2, courseId);
            pstmt.executeUpdate();
            System.out.println("Course assigned to staff.");
        }
    }

    // View all staff
    public void viewAllStaff() throws SQLException {
        String sql = "SELECT a.staff_id, u.username, u.email, d.name AS department_name " +
                     "FROM academic_staff a " +
                     "JOIN users u ON a.user_id = u.user_id " +
                     "JOIN departments d ON a.department_id = d.department_id";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("staff_id") +
                                   ", Username: " + rs.getString("username") +
                                   ", Email: " + rs.getString("email") +
                                   ", Department: " + rs.getString("department_name"));
            }
        }
    }

    // Set office hours (assuming you have a field in DB)
    public void setOfficeHours(int staffId, String officeHours) throws SQLException {
        String sql = "UPDATE academic_staff SET office_hours = ? WHERE staff_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, officeHours);
            pstmt.setInt(2, staffId);
            int rows = pstmt.executeUpdate();
            System.out.println(rows > 0 ? "Office hours updated." : "Staff not found.");
        }
    }
}
