package university;
import java.sql.*;
import java.util.*;
public class University {
    static final String dbURL = "jdbc:mysql://localhost:3306/universitydatabase";
    public static void main(String[] args) throws Exception {
        Connection conn = null;
        conn = DriverManager.getConnection(dbURL, "root", "");
       
        UserManager stu = new UserManager(conn);
        StudentManager stud = new StudentManager(conn);
        stud.deleteStudent(22);
       
       
      
        
       
    }
   
        }
