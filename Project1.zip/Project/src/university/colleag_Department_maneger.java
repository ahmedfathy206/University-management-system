
package university;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class colleag_Department_maneger extends DatabaseHandler {
    
public colleag_Department_maneger(Connection conn) {
        super(conn);
    }

    // Add a new college
    public boolean addCollege(String name, int universityId) throws SQLException {
        String sql = "INSERT INTO colleges (name, university_id) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.setInt(2, universityId);
            int rowsInserted = stmt.executeUpdate();
            System.out.println("College added: " + name);
            return rowsInserted > 0;
        }
    }

    // Add a new department
    public boolean addDepartment(String name, int collegeId) throws SQLException {
        String sql = "INSERT INTO departments (name, college_id) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.setInt(2, collegeId);
            int rowsInserted = stmt.executeUpdate();
            System.out.println("Department added: " + name);
            return rowsInserted > 0;
        }
    }

    // Get list of colleges for a given university
    public List<String> getColleges(int universityId) throws SQLException {
        List<String> colleges = new ArrayList<>();
        String sql = "SELECT name FROM colleges WHERE university_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, universityId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                colleges.add(rs.getString("name"));
            }
        }
        return colleges;
    }

    // Get list of departments for a given college
    public List<String> getDepartments(int collegeId) throws SQLException {
        List<String> departments = new ArrayList<>();
        String sql = "SELECT name FROM departments WHERE college_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, collegeId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                departments.add(rs.getString("name"));
            }
        }
        return departments;
    }
}
